package ba.unsa.etf.rpr.tut1;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
