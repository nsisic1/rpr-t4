package ba.unsa.etf.rpr.tut1;

class LicniSemestar extends Semestar {
    private Semestar planSemestra;
    private int zbirECTS;

    LicniSemestar() {}

        int getZbirECTSCTS() {
        return zbirECTS;
    }

    void upisiPredmet(Predmet predmet) {}
    void ispisiPredmet(Predmet predmet) {}
}
